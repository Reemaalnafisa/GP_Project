package com.example.gat_helper_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
